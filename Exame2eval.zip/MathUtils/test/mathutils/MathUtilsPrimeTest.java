
package mathutils;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class MathUtilsPrimeTest {

    private Integer result;
    private Boolean expResult;

    public MathUtilsPrimeTest(Integer result, Boolean expResult) {
        this.result = result;
        this.expResult = expResult;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> datos() {
        return Arrays.asList(new Object[][]{
            {0, false},
            {1, false},
            {3, true},
            {6, false},
            {7, true},
            {10, false}});
    }

    /**
     * Test of isPrime method, of class MathUtils.
     */
    @Test
    public void testIsPrime() {
        int n = 0;
        boolean expResult = false;
        boolean result = MathUtils.isPrime(n);
        assertEquals(expResult, result);

    }

}
