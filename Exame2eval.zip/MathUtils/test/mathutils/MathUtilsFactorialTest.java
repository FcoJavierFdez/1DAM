package mathutils;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class MathUtilsFactorialTest {

    private static MathUtils instance;
    private Integer result;
    private Integer expResult;

    public MathUtilsFactorialTest(Integer result, Integer expResult) {
        this.result = result;
        this.expResult = expResult;
    }

    @Parameters
    public static Collection<Object[]> datos() {
        return Arrays.asList(new Object[][]{
            {1, 1},
            {2, 2},
            {3, 6},
            {4, 24},
            {5, 120}});
    }

    /*@BeforeClass
    public static void setUpClass() {
        instance = new MathUtils(); 
    }
     */

    /**
     * Test of factorial method, of class MathUtils.
     */
    @Test
    public void testFactorial() {
        instance = new MathUtils();
        int n = 0;
        int expResult = 0;
        int result = MathUtils.factorial(n);
        assertEquals(expResult, result);

    }

}
