
package mathutils;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({mathutils.MathUtilsFactorialTest.class, mathutils.MathUtilsFibonacciTest.class, mathutils.MathUtilsPrimeTest.class})
public class TestSuite {

  
    
}
