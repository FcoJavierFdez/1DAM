package mathutils;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class MathUtilsFibonacciTest {

    private Integer result;
    private Integer expResult;

    public MathUtilsFibonacciTest(Integer result, Integer expResult) {
        this.result = result;
        this.expResult = expResult;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> datos() {
        return Arrays.asList(new Object[][]{
            {1, 1},
            {2, 1},
            {4, 3},
            {6, 8},
            {7, 13}});
    }

    /**
     * Test of fibonacci method, of class MathUtils.
     */
    @Test
    public void testFibonacci() {

        int n = 0;
        int expResult = 0;
        int result = MathUtils.fibonacci(n);
        assertEquals(expResult, result);

    }

}
